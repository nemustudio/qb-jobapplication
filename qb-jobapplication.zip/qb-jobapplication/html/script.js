let currentMode = 'apply';
let jobsConfig = {};
let statusConfig = {};
let currentApplications = [];
let currentApplicationDetail = null;

// =====================================
// UIの初期化とデータ受信
// =====================================
window.addEventListener('message', function(event) {
    const data = event.data;
    
    if (data.action === 'open') {
        currentMode = data.mode;
        jobsConfig = data.jobs;
        statusConfig = data.status;
        
        openUI(data.mode);
    } else if (data.action === 'close') {
        closeUI();
    }
});

function openUI(mode) {
    const container = document.getElementById('container');
    container.classList.remove('hidden');
    
    // すべてのビューを非表示
    document.querySelectorAll('.view').forEach(view => view.classList.add('hidden'));
    
    // モードに応じてビューを表示
    if (mode === 'apply') {
        document.getElementById('ui-title').textContent = 'ジョブ応募';
        document.getElementById('apply-view').classList.remove('hidden');
        loadJobOptions();
    } else if (mode === 'my') {
        document.getElementById('ui-title').textContent = '自分の申請一覧';
        document.getElementById('my-view').classList.remove('hidden');
        loadMyApplications();
    } else if (mode === 'manage') {
        document.getElementById('ui-title').textContent = '申請管理';
        document.getElementById('manage-view').classList.remove('hidden');
        loadManageApplications();
    }
}

function closeUI() {
    document.getElementById('container').classList.add('hidden');
    fetch(`https://${GetParentResourceName()}/close`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({})
    });
}

// =====================================
// 応募フォーム
// =====================================
function loadJobOptions() {
    const select = document.getElementById('job-select');
    select.innerHTML = '<option value="">ジョブを選択してください</option>';
    
    for (const [jobKey, jobData] of Object.entries(jobsConfig)) {
        const option = document.createElement('option');
        option.value = jobKey;
        option.textContent = jobData.label;
        select.appendChild(option);
    }
    
    // ジョブ選択時に要件を表示
    select.addEventListener('change', function() {
        const requirements = document.getElementById('job-requirements');
        if (this.value && jobsConfig[this.value]) {
            requirements.textContent = jobsConfig[this.value].requirementText;
            requirements.style.display = 'block';
        } else {
            requirements.style.display = 'none';
        }
    });
    
    // 文字数カウント
    const textarea = document.getElementById('application-message');
    textarea.addEventListener('input', function() {
        document.getElementById('char-count').textContent = this.value.length;
    });
}

function submitApplication() {
    const job = document.getElementById('job-select').value;
    const message = document.getElementById('application-message').value.trim();
    
    if (!job) {
        alert('ジョブを選択してください');
        return;
    }
    
    if (!message) {
        alert('申請内容を入力してください');
        return;
    }
    
    fetch(`https://${GetParentResourceName()}/submitApplication`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            job: job,
            message: message
        })
    }).then(() => {
        // フォームをリセット
        document.getElementById('job-select').value = '';
        document.getElementById('application-message').value = '';
        document.getElementById('char-count').textContent = '0';
        document.getElementById('job-requirements').style.display = 'none';
        
        closeUI();
    });
}

// =====================================
// 自分の申請一覧
// =====================================
function loadMyApplications() {
    fetch(`https://${GetParentResourceName()}/getApplications`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({type: 'my'})
    }).then(response => response.json())
      .then(applications => {
          currentApplications = applications || [];
          displayMyApplications(currentApplications);
      });
}

function displayMyApplications(applications) {
    const container = document.getElementById('my-applications-container');
    
    if (!applications || applications.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <h3>申請がありません</h3>
                <p>/jobap コマンドで新しい申請を送信できます</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '';
    applications.forEach(app => {
        const card = createApplicationCard(app, false);
        container.appendChild(card);
    });
}

// =====================================
// 管理者ビュー
// =====================================
function loadManageApplications() {
    fetch(`https://${GetParentResourceName()}/getApplications`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({type: 'manage'})
    }).then(response => response.json())
      .then(applications => {
          currentApplications = applications || [];
          displayManageApplications(currentApplications);
      });
}

function displayManageApplications(applications) {
    const container = document.getElementById('manage-applications-container');
    
    if (!applications || applications.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <h3>申請がありません</h3>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '';
    applications.forEach(app => {
        const card = createApplicationCard(app, true);
        container.appendChild(card);
    });
}

function filterApplications() {
    const filter = document.getElementById('status-filter').value;
    
    if (filter === 'all') {
        displayManageApplications(currentApplications);
    } else {
        const filtered = currentApplications.filter(app => app.status === filter);
        displayManageApplications(filtered);
    }
}

// =====================================
// 申請カードの作成
// =====================================
function createApplicationCard(app, isManage) {
    const card = document.createElement('div');
    card.className = 'application-card';
    card.onclick = () => showApplicationDetail(app, isManage);
    
    const statusClass = `status-${app.status}`;
    const statusLabel = statusConfig[app.status]?.label || app.status;
    
    const jobLabel = jobsConfig[app.job]?.label || app.job;
    
    // メッセージを短縮表示
    const shortMessage = app.message.length > 150 
        ? app.message.substring(0, 150) + '...' 
        : app.message;
    
    card.innerHTML = `
        <div class="application-card-header">
            <div class="application-info">
                <h3>${jobLabel}</h3>
                <p>${isManage ? '応募者: ' + app.name : '応募日: ' + formatDate(app.created_at)}</p>
            </div>
            <span class="status-badge ${statusClass}">${statusLabel}</span>
        </div>
        <div class="application-message">${shortMessage}</div>
        <div class="application-date">
            ${isManage ? '応募日: ' + formatDate(app.created_at) : ''}
            ${app.reviewed_at ? ' | 審査日: ' + formatDate(app.reviewed_at) : ''}
        </div>
    `;
    
    return card;
}

// =====================================
// 申請詳細モーダル
// =====================================
function showApplicationDetail(app, isManage) {
    currentApplicationDetail = app;
    
    const modal = document.getElementById('detail-modal');
    const content = document.getElementById('detail-content');
    const actions = document.getElementById('detail-actions');
    
    const statusClass = `status-${app.status}`;
    const statusLabel = statusConfig[app.status]?.label || app.status;
    const jobLabel = jobsConfig[app.job]?.label || app.job;
    
    content.innerHTML = `
        <div class="detail-row">
            <div class="detail-label">ジョブ</div>
            <div class="detail-value">${jobLabel}</div>
        </div>
        <div class="detail-row">
            <div class="detail-label">応募者</div>
            <div class="detail-value">${app.name}</div>
        </div>
        <div class="detail-row">
            <div class="detail-label">ステータス</div>
            <div class="detail-value">
                <span class="status-badge ${statusClass}">${statusLabel}</span>
            </div>
        </div>
        <div class="detail-row">
            <div class="detail-label">志望動機・自己PR</div>
            <div class="detail-value">${app.message}</div>
        </div>
        <div class="detail-row">
            <div class="detail-label">応募日時</div>
            <div class="detail-value">${formatDate(app.created_at)}</div>
        </div>
        ${app.reviewed_by ? `
            <div class="detail-row">
                <div class="detail-label">審査者</div>
                <div class="detail-value">${app.reviewed_by}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">審査日時</div>
                <div class="detail-value">${formatDate(app.reviewed_at)}</div>
            </div>
        ` : ''}
        ${app.response ? `
            <div class="detail-row">
                <div class="detail-label">返信</div>
                <div class="detail-value">${app.response}</div>
            </div>
        ` : ''}
        <div id="comments-container" class="comments-section"></div>
    `;
    
    // アクションボタン
    actions.innerHTML = '';
    
    if (isManage && app.status === 'pending') {
        actions.innerHTML = `
            <button class="action-btn btn-approve" onclick="updateStatus(${app.id}, 'approved')">承認</button>
            <button class="action-btn btn-interview" onclick="updateStatus(${app.id}, 'interview')">面接</button>
            <button class="action-btn btn-reject" onclick="updateStatus(${app.id}, 'rejected')">却下</button>
        `;
    } else if (!isManage && app.status === 'pending') {
        actions.innerHTML = `
            <button class="action-btn btn-delete" onclick="deleteApplication(${app.id})">申請を取り消す</button>
        `;
    }
    
    // コメントをロード
    loadComments(app.id, isManage);
    
    modal.classList.remove('hidden');
}

function closeDetailModal() {
    document.getElementById('detail-modal').classList.add('hidden');
}

// =====================================
// ステータス更新
// =====================================
let pendingStatusUpdate = null;

function updateStatus(id, status) {
    // ステータス更新情報を保存
    pendingStatusUpdate = { id, status };
    
    // 返信メッセージ入力モーダルを開く
    openResponseModal(status);
}

function openResponseModal(status) {
    const modal = document.getElementById('response-modal');
    const textarea = document.getElementById('response-message');
    const confirmBtn = document.getElementById('confirm-status-btn');
    
    // テキストエリアをクリア
    textarea.value = '';
    
    // 確認ボタンのテキストを更新
    let statusLabel = '';
    if (status === 'approved') statusLabel = '承認';
    else if (status === 'rejected') statusLabel = '却下';
    else if (status === 'interview') statusLabel = '面接設定';
    
    confirmBtn.textContent = statusLabel + 'を確定';
    
    // 確認ボタンのイベントを設定
    confirmBtn.onclick = confirmStatusUpdate;
    
    // モーダルを表示
    modal.classList.remove('hidden');
}

function closeResponseModal() {
    document.getElementById('response-modal').classList.add('hidden');
    pendingStatusUpdate = null;
}

function confirmStatusUpdate() {
    if (!pendingStatusUpdate) return;
    
    const response = document.getElementById('response-message').value.trim();
    
    fetch(`https://${GetParentResourceName()}/updateStatus`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            id: pendingStatusUpdate.id,
            status: pendingStatusUpdate.status,
            response: response || ''
        })
    }).then(() => {
        closeResponseModal();
        closeDetailModal();
        loadManageApplications();
    });
}

// =====================================
// 申請削除
// =====================================
function deleteApplication(id) {
    if (confirm('本当にこの申請を取り消しますか?')) {
        fetch(`https://${GetParentResourceName()}/deleteApplication`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: id})
        }).then(() => {
            closeDetailModal();
            loadMyApplications();
        });
    }
}

// =====================================
// コメント機能
// =====================================
function loadComments(applicationId, isManage) {
    fetch(`https://${GetParentResourceName()}/getComments`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id: applicationId})
    }).then(response => response.json())
      .then(comments => {
          displayComments(comments, applicationId, isManage);
      });
}

function displayComments(comments, applicationId, isManage) {
    const container = document.getElementById('comments-container');
    
    let html = '<h3>コメント</h3>';
    
    if (comments && comments.length > 0) {
        comments.forEach(comment => {
            html += `
                <div class="comment-item">
                    <div class="comment-author">${comment.commenter_name}</div>
                    <div class="comment-text">${comment.comment}</div>
                    <div class="comment-date">${formatDate(comment.created_at)}</div>
                </div>
            `;
        });
    }
    
    if (isManage) {
        html += `
            <div class="add-comment">
                <textarea id="new-comment" placeholder="コメントを追加..."></textarea>
                <button onclick="addComment(${applicationId})">コメントを送信</button>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

function addComment(applicationId) {
    const comment = document.getElementById('new-comment').value.trim();
    
    if (!comment) {
        alert('コメントを入力してください');
        return;
    }
    
    fetch(`https://${GetParentResourceName()}/addComment`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            id: applicationId,
            comment: comment
        })
    }).then(() => {
        loadComments(applicationId, true);
    });
}

// =====================================
// ユーティリティ関数
// =====================================
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString('ja-JP', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function GetParentResourceName() {
    return 'qb-jobapplication';
}

// ESCキーでUIを閉じる
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const responseModal = document.getElementById('response-modal');
        const detailModal = document.getElementById('detail-modal');
        
        // 返信モーダルが開いている場合
        if (!responseModal.classList.contains('hidden')) {
            closeResponseModal();
        }
        // 詳細モーダルが開いている場合
        else if (!detailModal.classList.contains('hidden')) {
            closeDetailModal();
        }
        // メインUIを閉じる
        else {
            closeUI();
        }
    }
});
