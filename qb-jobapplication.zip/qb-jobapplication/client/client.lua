local QBCore = exports['qb-core']:GetCoreObject()
local isUIOpen = false

-- =====================================
-- /jobap コマンド
-- =====================================
RegisterCommand('jobap', function()
    local PlayerData = QBCore.Functions.GetPlayerData()
    
    -- UIを開く
    openApplicationUI('apply')
end)

-- =====================================
-- /jobapmanage コマンド（管理者用）
-- =====================================
RegisterCommand('jobapmanage', function()
    local PlayerData = QBCore.Functions.GetPlayerData()
    local job = PlayerData.job.name
    local grade = PlayerData.job.grade.level
    
    -- 権限チェック
    if not Config.Jobs[job] or grade < Config.Jobs[job].minGrade then
        QBCore.Functions.Notify('このジョブの申請を管理する権限がありません', 'error')
        return
    end
    
    openApplicationUI('manage')
end)

-- =====================================
-- /myjobaps コマンド（自分の申請確認）
-- =====================================
RegisterCommand('myjobaps', function()
    openApplicationUI('my')
end)

-- =====================================
-- UIを開く
-- =====================================
function openApplicationUI(mode)
    if isUIOpen then return end
    
    isUIOpen = true
    SetNuiFocus(true, true)
    
    local PlayerData = QBCore.Functions.GetPlayerData()
    
    SendNUIMessage({
        action = 'open',
        mode = mode,
        jobs = Config.Jobs,
        status = Config.Status,
        playerJob = PlayerData.job.name,
        playerGrade = PlayerData.job.grade.level
    })
end

-- =====================================
-- UIを閉じる
-- =====================================
RegisterNUICallback('close', function(data, cb)
    isUIOpen = false
    SetNuiFocus(false, false)
    cb('ok')
end)

-- =====================================
-- 申請を送信
-- =====================================
RegisterNUICallback('submitApplication', function(data, cb)
    TriggerServerEvent('qb-jobapplication:server:submitApplication', data)
    cb('ok')
end)

-- =====================================
-- 申請一覧を取得
-- =====================================
RegisterNUICallback('getApplications', function(data, cb)
    QBCore.Functions.TriggerCallback('qb-jobapplication:server:getApplications', function(applications)
        cb(applications)
    end, data.type)
end)

-- =====================================
-- ステータス更新
-- =====================================
RegisterNUICallback('updateStatus', function(data, cb)
    TriggerServerEvent('qb-jobapplication:server:updateStatus', data)
    cb('ok')
end)

-- =====================================
-- コメント追加
-- =====================================
RegisterNUICallback('addComment', function(data, cb)
    TriggerServerEvent('qb-jobapplication:server:addComment', data)
    cb('ok')
end)

-- =====================================
-- コメント一覧を取得
-- =====================================
RegisterNUICallback('getComments', function(data, cb)
    QBCore.Functions.TriggerCallback('qb-jobapplication:server:getComments', function(comments)
        cb(comments)
    end, data.id)
end)

-- =====================================
-- 申請を削除
-- =====================================
RegisterNUICallback('deleteApplication', function(data, cb)
    TriggerServerEvent('qb-jobapplication:server:deleteApplication', data.id)
    cb('ok')
end)

-- =====================================
-- キーボードでのUI終了
-- =====================================
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if isUIOpen then
            if IsControlJustReleased(0, 322) then -- ESC key
                SendNUIMessage({action = 'close'})
                isUIOpen = false
                SetNuiFocus(false, false)
            end
        else
            Citizen.Wait(500)
        end
    end
end)
