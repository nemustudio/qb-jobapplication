local QBCore = exports['qb-core']:GetCoreObject()

-- =====================================
-- 申請の作成
-- =====================================
RegisterNetEvent('qb-jobapplication:server:submitApplication', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    local citizenid = Player.PlayerData.citizenid
    local name = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
    local job = data.job
    local message = data.message
    local questions = json.encode(data.questions or {})
    
    -- バリデーション
    if not Config.Jobs[job] then
        TriggerClientEvent('QBCore:Notify', src, '無効なジョブです', 'error')
        return
    end
    
    if not message or message == '' then
        TriggerClientEvent('QBCore:Notify', src, '申請内容を入力してください', 'error')
        return
    end
    
    if #message > Config.MaxApplicationLength then
        TriggerClientEvent('QBCore:Notify', src, '申請内容が長すぎます', 'error')
        return
    end
    
    -- アクティブな申請数をチェック
    MySQL.query('SELECT COUNT(*) as count FROM job_applications WHERE citizenid = ? AND status = ?', {
        citizenid, 'pending'
    }, function(result)
        if result[1].count >= Config.MaxActiveApplications then
            TriggerClientEvent('QBCore:Notify', src, '同時に応募できる数を超えています', 'error')
            return
        end
        
        -- クールダウンをチェック
        MySQL.query('SELECT created_at FROM job_applications WHERE citizenid = ? AND job = ? ORDER BY created_at DESC LIMIT 1', {
            citizenid, job
        }, function(lastApp)
            if lastApp[1] then
                local lastTime = os.time(lastApp[1].created_at)
                local cooldownEnd = lastTime + (Config.ApplicationCooldown * 3600)
                
                if os.time() < cooldownEnd then
                    local hoursLeft = math.ceil((cooldownEnd - os.time()) / 3600)
                    TriggerClientEvent('QBCore:Notify', src, '再申請まで ' .. hoursLeft .. ' 時間待つ必要があります', 'error')
                    return
                end
            end
            
            -- 申請を保存
            MySQL.insert('INSERT INTO job_applications (citizenid, name, job, message, questions, status) VALUES (?, ?, ?, ?, ?, ?)', {
                citizenid, name, job, message, questions, 'pending'
            }, function(id)
                if id then
                    TriggerClientEvent('QBCore:Notify', src, '申請を送信しました', 'success')
                    
                    -- ジョブを持っているプレイヤーに通知
                    notifyJobMembers(job, name .. ' さんから新しい申請が届きました')
                else
                    TriggerClientEvent('QBCore:Notify', src, '申請の送信に失敗しました', 'error')
                end
            end)
        end)
    end)
end)

-- =====================================
-- 申請一覧を取得
-- =====================================
QBCore.Functions.CreateCallback('qb-jobapplication:server:getApplications', function(source, cb, type)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then 
        cb(nil)
        return 
    end
    
    local citizenid = Player.PlayerData.citizenid
    local job = Player.PlayerData.job.name
    local grade = Player.PlayerData.job.grade.level
    
    if type == 'my' then
        -- 自分の申請を取得
        MySQL.query('SELECT * FROM job_applications WHERE citizenid = ? ORDER BY created_at DESC', {
            citizenid
        }, function(results)
            cb(results)
        end)
    elseif type == 'manage' then
        -- 管理者として申請を確認
        if not Config.Jobs[job] then
            cb(nil)
            return
        end
        
        if grade < Config.Jobs[job].minGrade then
            TriggerClientEvent('QBCore:Notify', src, '権限がありません', 'error')
            cb(nil)
            return
        end
        
        MySQL.query('SELECT * FROM job_applications WHERE job = ? ORDER BY created_at DESC', {
            job
        }, function(results)
            cb(results)
        end)
    end
end)

-- =====================================
-- 申請のステータス更新
-- =====================================
RegisterNetEvent('qb-jobapplication:server:updateStatus', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    local job = Player.PlayerData.job.name
    local grade = Player.PlayerData.job.grade.level
    local applicationId = data.id
    local newStatus = data.status
    local response = data.response or ''
    
    -- 権限チェック
    if not Config.Jobs[job] or grade < Config.Jobs[job].minGrade then
        TriggerClientEvent('QBCore:Notify', src, '権限がありません', 'error')
        return
    end
    
    -- 申請を取得
    MySQL.query('SELECT * FROM job_applications WHERE id = ? AND job = ?', {
        applicationId, job
    }, function(result)
        if not result[1] then
            TriggerClientEvent('QBCore:Notify', src, '申請が見つかりません', 'error')
            return
        end
        
        local application = result[1]
        local reviewerName = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
        
        -- ステータスを更新
        MySQL.update('UPDATE job_applications SET status = ?, reviewed_by = ?, reviewed_at = NOW(), response = ? WHERE id = ?', {
            newStatus, reviewerName, response, applicationId
        }, function(affectedRows)
            if affectedRows > 0 then
                TriggerClientEvent('QBCore:Notify', src, 'ステータスを更新しました', 'success')
                
                -- 申請者がオンラインの場合は通知
                local targetPlayer = QBCore.Functions.GetPlayerByCitizenId(application.citizenid)
                if targetPlayer then
                    TriggerClientEvent('QBCore:Notify', targetPlayer.PlayerData.source, 
                        'あなたの ' .. Config.Jobs[job].label .. ' への申請が ' .. Config.Status[newStatus].label .. ' されました', 
                        newStatus == 'approved' and 'success' or 'error')
                end
            else
                TriggerClientEvent('QBCore:Notify', src, '更新に失敗しました', 'error')
            end
        end)
    end)
end)

-- =====================================
-- 申請に返信
-- =====================================
RegisterNetEvent('qb-jobapplication:server:addComment', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    local job = Player.PlayerData.job.name
    local grade = Player.PlayerData.job.grade.level
    local applicationId = data.id
    local comment = data.comment
    
    -- 権限チェック
    if not Config.Jobs[job] or grade < Config.Jobs[job].minGrade then
        TriggerClientEvent('QBCore:Notify', src, '権限がありません', 'error')
        return
    end
    
    local commenterName = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
    
    MySQL.insert('INSERT INTO job_application_comments (application_id, commenter_name, comment) VALUES (?, ?, ?)', {
        applicationId, commenterName, comment
    }, function(id)
        if id then
            TriggerClientEvent('QBCore:Notify', src, 'コメントを追加しました', 'success')
        else
            TriggerClientEvent('QBCore:Notify', src, 'コメントの追加に失敗しました', 'error')
        end
    end)
end)

-- =====================================
-- コメント一覧を取得
-- =====================================
QBCore.Functions.CreateCallback('qb-jobapplication:server:getComments', function(source, cb, applicationId)
    MySQL.query('SELECT * FROM job_application_comments WHERE application_id = ? ORDER BY created_at ASC', {
        applicationId
    }, function(results)
        cb(results)
    end)
end)

-- =====================================
-- 申請を削除
-- =====================================
RegisterNetEvent('qb-jobapplication:server:deleteApplication', function(applicationId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    local citizenid = Player.PlayerData.citizenid
    
    MySQL.query('SELECT * FROM job_applications WHERE id = ? AND citizenid = ?', {
        applicationId, citizenid
    }, function(result)
        if result[1] and result[1].status == 'pending' then
            MySQL.execute('DELETE FROM job_applications WHERE id = ?', {applicationId}, function()
                TriggerClientEvent('QBCore:Notify', src, '申請を削除しました', 'success')
            end)
        else
            TriggerClientEvent('QBCore:Notify', src, '削除できません', 'error')
        end
    end)
end)

-- =====================================
-- ヘルパー関数：ジョブメンバーに通知
-- =====================================
function notifyJobMembers(job, message)
    local Players = QBCore.Functions.GetQBPlayers()
    for _, Player in pairs(Players) do
        if Player.PlayerData.job.name == job then
            local grade = Player.PlayerData.job.grade.level
            if Config.Jobs[job] and grade >= Config.Jobs[job].minGrade then
                TriggerClientEvent('QBCore:Notify', Player.PlayerData.source, message, 'info')
            end
        end
    end
end
