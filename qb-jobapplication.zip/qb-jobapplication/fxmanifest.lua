fx_version 'cerulean'
game 'gta5'

author 'Your Name'
description 'QBCore Job Application System - Similar to Minecraft Staff Application'
version '1.0.0'

shared_scripts {
    'config/config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

lua54 'yes'
