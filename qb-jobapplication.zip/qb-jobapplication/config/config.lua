Config = {}

-- 応募可能なジョブの設定
Config.Jobs = {
    ['police'] = {
        label = '警察署',
        minGrade = 2, -- この階級以上が申請を確認できる
        requirementText = '要件: 18歳以上、無犯罪歴'
    },
    ['ambulance'] = {
        label = '救急医療',
        minGrade = 2,
        requirementText = '要件: 医療知識、18歳以上'
    },
    ['mechanic'] = {
        label = '整備士',
        minGrade = 2,
        requirementText = '要件: 車両整備の知識'
    },
    ['realestate'] = {
        label = '不動産業',
        minGrade = 1,
        requirementText = '要件: コミュニケーション能力'
    },
    ['taxi'] = {
        label = 'タクシー会社',
        minGrade = 1,
        requirementText = '要件: 運転免許、無犯罪歴'
    },
    ['bus'] = {
        label = 'バス会社',
        minGrade = 1,
        requirementText = '要件: 運転免許、安全運転'
    },
    ['cardealer'] = {
        label = '車両販売店',
        minGrade = 1,
        requirementText = '要件: 販売経験歓迎'
    },
    ['tow'] = {
        label = 'レッカー会社',
        minGrade = 1,
        requirementText = '要件: 運転技術、体力'
    }
}

-- 申請ステータス
Config.Status = {
    pending = {label = '審査中', color = '#FFA500'},
    approved = {label = '承認', color = '#00FF00'},
    rejected = {label = '却下', color = '#FF0000'},
    interview = {label = '面接予定', color = '#00BFFF'}
}

-- 通知設定
Config.Notifications = {
    enabled = true,
    discord = false, -- Discord Webhookを使う場合はtrue
    discordWebhook = '' -- Discord WebhookのURL
}

-- その他の設定
Config.MaxApplicationLength = 1000 -- 申請文の最大文字数
Config.ApplicationCooldown = 24 -- 再申請までの待機時間（時間単位）
Config.MaxActiveApplications = 3 -- 同時に応募できる最大数
